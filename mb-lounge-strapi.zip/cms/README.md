# MB Lounge CMS

This is the Strapi 5 content backend for the static GitHub Pages site. Editors can manage the live event calendar, the homepage’s reorderable content blocks, campaign copy, brand colors, logo files, typography presets, page spacing, social links, and the public video embed.

## Run locally

1. Use a supported Node.js LTS release (the current Strapi 5 docs list Node 22, 24, and 26).
2. From this directory, copy `.env.example` to `.env`, replace every secret with a unique random value, and point `DATABASE_URL` to a PostgreSQL database you control. SQLite can be selected with `DATABASE_CLIENT=sqlite` for a disposable local sandbox.
3. Run `npm install`, then `npm run develop`.
4. Create the first Strapi administrator in the browser at `http://localhost:1337/admin`.
5. The first boot seeds Site settings and a Homepage draft published with the MB Lounge content, the four WordPress slideshow photos, and the existing RTSP.me embed. No event dates are invented; create event entries in Content Manager as dates are confirmed.

## Public website connection

The public read-only endpoint is `GET /api/public/site`. It returns only published site settings, homepage blocks, and future events. It requires no API token and uses a short public cache. The endpoint is deliberately separate from Strapi’s general content API.

Set `window.MB_LOUNGE_CMS_URL` to the Strapi origin (for example `https://cms.example.com`) before `script.js` loads. Configure `CORS_ORIGINS` on Strapi with the exact website origin, such as `https://commerce-dash.github.io`. Never place a Strapi admin token or write token in the public website.

The Pages site can serve the frontend, but it cannot run Strapi or its database. Deploy this `cms/` app and PostgreSQL to a Strapi-compatible backend host before editors can publish changes to the live preview. Keep the existing GitHub Pages hostname during this preview stage; the custom domain is not set by this CMS.

## Editorial model

- **Homepage** is a single type. Its `sections` dynamic zone lets an editor add, remove, and reorder hero, events, story, private events, community, live video, campaign banner, rich text, photo gallery, and partner logo blocks.
- **Event** is a collection type with Draft & Publish, dates, event type, summary, event details, image, price, and ticket link.
- **Site settings** controls logos, palette, font presets/font files, layout spacing, nav and social links, SEO defaults, and the announcement bar.
- **Live video** accepts the existing RTSP.me player. The frontend validates the host and embed path before it creates an iframe; arbitrary embed code is not accepted.

The supplied WordPress slideshow image URLs are the seeded starting content. Upload replacement/current images to Strapi Media Library before retiring WordPress so the new site owns its media independently.
