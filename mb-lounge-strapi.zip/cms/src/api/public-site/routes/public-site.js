module.exports = {
  routes: [
    {
      method: 'GET',
      path: '/public/site',
      handler: 'public-site.find',
      config: { auth: false, policies: [], middlewares: [] },
    },
  ],
};
