const sectionComponents = [
  'sections.hero',
  'sections.event-list',
  'sections.story',
  'sections.private-events',
  'sections.community',
  'sections.live-video',
  'sections.promo-banner',
  'sections.rich-text',
  'sections.photo-gallery',
  'sections.logo-grid',
];

const imageFields = { fields: ['url', 'alternativeText', 'width', 'height', 'formats'] };
const sectionPopulates = {
  'sections.hero': { populate: { slides: { populate: { image: imageFields } }, primaryAction: true, secondaryAction: true, style: true } },
  'sections.event-list': { populate: { style: true } },
  'sections.story': { populate: { image: imageFields, style: true } },
  'sections.private-events': { populate: { image: imageFields, action: true, style: true } },
  'sections.community': { populate: { action: true, style: true } },
  'sections.live-video': { populate: { poster: imageFields, style: true } },
  'sections.promo-banner': { populate: { image: imageFields, action: true, style: true } },
  'sections.rich-text': { populate: { style: true } },
  'sections.photo-gallery': { populate: { images: true, style: true } },
  'sections.logo-grid': { populate: { logos: { populate: { logo: imageFields } }, style: true } },
};

module.exports = {
  async find(ctx) {
    const { strapi } = ctx;
    const settings = await strapi.documents('api::site-setting.site-setting').findFirst({
      status: 'published',
      populate: {
        brand: { populate: { logo: imageFields, alternateLogo: imageFields, favicon: imageFields } },
        typography: { populate: { headingFontFile: imageFields, bodyFontFile: imageFields } },
        marketing: { populate: { promoImage: imageFields } },
        navigation: true,
        socialLinks: true,
      },
    });

    const homepage = await strapi.documents('api::home-page.home-page').findFirst({
      status: 'published',
      populate: {
        seo: true,
        sections: {
          on: Object.fromEntries(sectionComponents.map((uid) => [uid, sectionPopulates[uid] || { populate: '*' }])),
        },
      },
    });

    const now = new Date().toISOString();
    const events = await strapi.documents('api::event.event').findMany({
      status: 'published',
      filters: { startsAt: { $gte: now } },
      sort: ['startsAt:asc'],
      pagination: { page: 1, pageSize: 12 },
      populate: { cover: imageFields },
    });

    ctx.set('Cache-Control', 'public, max-age=60, stale-while-revalidate=300');
    ctx.body = { data: { settings, homepage, events } };
  },
};
