const { createInitialContent } = require('./seed/default-content');

module.exports = {
  async bootstrap({ strapi }) {
    await createInitialContent(strapi);
  },
};
