const paragraph = (text) => [{ type: 'paragraph', children: [{ type: 'text', text }] }];

const defaultSettings = {
  siteName: 'The MB Lounge',
  brand: {
    primaryColor: '#211a1d',
    accentColor: '#dc7da4',
    highlightColor: '#ef9bbd',
    surfaceColor: '#f6f1eb',
    textColor: '#211a1d',
  },
  typography: { headingFont: 'Playfair Display', bodyFont: 'DM Sans' },
  layout: { contentWidth: 'standard', sectionSpacing: 'standard', roundedCorners: false },
  marketing: {
    announcementEnabled: true,
    announcementText: 'Worcester’s original LGBTQ+ lounge — proudly here since 1971',
    defaultShareTitle: 'MB Lounge — Worcester, MA',
    defaultShareDescription: 'Since 1971, MB Lounge has been Worcester’s neighborhood LGBTQ+ bar for dancing, live events, and good company.',
  },
  navigation: [
    { label: 'What’s on', url: '#events' },
    { label: 'Our story', url: '#about' },
    { label: 'Private events', url: '#private-events' },
    { label: 'Community', url: '#community' },
    { label: 'Find us', url: '#visit' },
  ],
  socialLinks: [
    { label: 'Instagram', url: 'https://www.instagram.com/mb.lounge1/', platform: 'instagram' },
    { label: 'Facebook', url: 'https://www.facebook.com/MBLoungeWorcester/', platform: 'facebook' },
  ],
};

const defaultHomepage = {
  seo: {
    title: 'MB Lounge — Worcester, MA',
    description: 'Since 1971, MB Lounge has been Worcester’s neighborhood LGBTQ+ bar for dancing, live events, and good company.',
  },
  sections: [
    {
      __component: 'sections.hero',
      eyebrow: 'A Worcester original since 1971',
      heading: 'Your night.',
      accentHeading: 'Your people.',
      body: 'A neighborhood lounge with a little more sparkle. Come for the music, stay for the community.',
      slides: [
        { imageUrl: 'assets/lounge/mb-lounge-dance-floor.jpg', altText: 'The MB Lounge dance floor lit in blue and green' },
        { imageUrl: 'assets/lounge/mb-lounge-bar-wide.jpg', altText: 'The colorful Worcester skyline mural inside MB Lounge' },
        { imageUrl: 'assets/lounge/mb-lounge-bar-taps.jpg', altText: 'Rainbow flags and taps behind the MB Lounge bar' },
        { imageUrl: 'assets/lounge/mb-lounge-lights.jpg', altText: 'Colorful stage lights across the MB Lounge dance floor' },
      ],
      slideDuration: 5000,
      transitionDuration: 500,
      transition: 'fade',
      primaryAction: { label: 'See what’s on', url: '#events', style: 'primary' },
      secondaryAction: { label: 'Plan your visit', url: '#visit', style: 'quiet' },
      style: { background: 'dark', contentWidth: 'wide', spacing: 'standard', alignment: 'left' },
    },
    {
      __component: 'sections.event-list',
      eyebrow: 'Save yourself a spot on the dance floor',
      heading: 'Coming up',
      accentHeading: 'at the Lounge.',
      intro: 'Special events and times can change. Check the live listings for what’s next.',
      maxEvents: 3,
      allEventsUrl: 'https://www.facebook.com/MBLoungeWorcester/events',
    },
    {
      __component: 'sections.story',
      eyebrow: 'A little history, a lot of heart',
      heading: 'Worcester’s',
      accentHeading: 'living room.',
      body: paragraph('The MB has been part of Worcester’s story since 1971. We’re proudly LGBTQ+ owned and operated, and we’ve always believed a good neighborhood bar makes room for everyone. Come dance, catch up, meet someone new—or just settle in for a drink. However you show up, there’s a place for you here.'),
      imageUrl: 'assets/lounge/mb-lounge-bar-wide.jpg',
      imageAlt: 'The MB Lounge in Worcester',
      statValue: '1971',
      statLabel: 'THE YEAR IT ALL STARTED',
      style: { background: 'dark', contentWidth: 'standard', spacing: 'spacious', alignment: 'left' },
    },
    {
      __component: 'sections.private-events',
      eyebrow: 'Make the night yours',
      heading: 'A room for',
      accentHeading: 'your kind of party.',
      body: paragraph('Big dance floor, full bar, and a central Worcester location. Host a celebration, bring your people together, and let us help make it a night.'),
      imageUrl: 'assets/lounge/mb-lounge-bar-taps.jpg',
      imageAlt: 'A colorful night on the MB Lounge dance floor',
      action: { label: 'Ask about a private event', url: 'mailto:mblounge1@gmail.com', style: 'primary' },
      style: { background: 'cream', contentWidth: 'standard', spacing: 'spacious', alignment: 'left' },
    },
    {
      __component: 'sections.community',
      eyebrow: 'Good neighbors know good neighbors',
      heading: 'Local love,',
      accentHeading: 'right around the corner.',
      body: paragraph('We’re proud to share our corner of Worcester with the independent businesses, artists, and community groups that make this city feel like home.'),
      action: { label: 'Talk community with us', url: 'mailto:mblounge1@gmail.com', style: 'quiet' },
      style: { background: 'paper', contentWidth: 'standard', spacing: 'spacious', alignment: 'left' },
    },
    {
      __component: 'sections.live-video',
      enabled: true,
      title: 'Live from the Lounge',
      caption: 'A live look inside MB Lounge. 21+ only.',
      provider: 'rtsp-me',
      embedUrl: 'https://rtsp.me/embed/t9e9hkrN/',
      aspectRatio: '16:9',
      style: { background: 'dark', contentWidth: 'standard', spacing: 'standard', alignment: 'left' },
    },
  ],
};

async function createInitialContent(strapi) {
  const settings = await strapi.documents('api::site-setting.site-setting').findFirst({ status: 'published' });
  if (!settings) {
    await strapi.documents('api::site-setting.site-setting').create({ data: defaultSettings, status: 'published' });
  }

  const homepage = await strapi.documents('api::home-page.home-page').findFirst({ status: 'published' });
  if (!homepage) {
    await strapi.documents('api::home-page.home-page').create({ data: defaultHomepage, status: 'published' });
  }
}

module.exports = { createInitialContent };
