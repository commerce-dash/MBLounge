module.exports = ({ env }) => {
  const client = env('DATABASE_CLIENT', 'postgres');
  const sslEnabled = env.bool('DATABASE_SSL', false);

  return {
    connection: {
      client,
      connection: client === 'sqlite'
        ? { filename: env('DATABASE_FILENAME', '.tmp/data.db') }
        : {
            connectionString: env('DATABASE_URL'),
            host: env('DATABASE_HOST'),
            port: env.int('DATABASE_PORT', 5432),
            database: env('DATABASE_NAME'),
            user: env('DATABASE_USERNAME'),
            password: env('DATABASE_PASSWORD'),
            ssl: sslEnabled ? { rejectUnauthorized: env.bool('DATABASE_SSL_REJECT_UNAUTHORIZED', true) } : false,
          },
      pool: { min: 0, max: env.int('DATABASE_POOL_MAX', 10) },
      useNullAsDefault: client === 'sqlite',
    },
  };
};
